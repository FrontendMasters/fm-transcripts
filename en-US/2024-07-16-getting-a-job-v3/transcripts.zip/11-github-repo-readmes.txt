[00:00:00]
>> Jerome Hardaway: Talk about the importance of a README. README is the first date of your code, right? Before they jump into your code, they're gonna look at your README, right? As you saw with the Vetsu Code app, it says what it does. It says the technologies that you're doing, it lets everyone know how to run it, everything.

[00:00:18]
Incorporating individual aids I did not do that with a BWC app, but you saw with the VS code thing. I had a visual aid right there showing this is how it looks to you. Let's go for it, and I'm going to probably go back and do this now that I've made it into this, into my, into my slides, clear installation instructions.

[00:00:42]
We showcase that. You should use guidelines, make sure you do that showcase on yours, any guy eyes for contributors. Now, you might not have projects that you want people to contribute to, but you should still have guidelines for contributors. You never know what type of tips you're gonna get, right?

[00:01:00]
And that creates, that turns your README and your repository into a networking tool. Now that I have, I'm opening up for contributors and feedback either through the discussions or through issues or whatever like that. I now have that opportunity to get that feedback, unsolicited feedback to build onto my project and make it better, right?

[00:01:24]
And that's what you want, I mean, if someone's going to come and take the time and look at your code and be like, hey, you should improve this, I always take that feedback as a gift, right? That's what you want, here's a free game. Yes, thank you, I'll take it and I'll incorporate it and I'll add it to my code base and add it to my repository, and I'll move forward with that.

[00:01:43]
So I want you all to take five minutes, identify some great read-me's that you would like, and then start thinking about how you're gonna copy those to your own read-me style, right? Awesome README list is by Maddest Singers. It's a great README, it has a whole list of good READMEs on here.

[00:02:02]
This is a great resource to look at, the, check out some good READMEs. Change log, generator, ease nav, it showcases all the good rules or great READMEs. So don't, GitHub.com, backslash a. Mathias Singers backslash awesome-README.
>> Jerome Hardaway: Thought everybody enjoyed that, did you do anything impactful for your README?

[00:02:33]
Awesome, yep, okay. What about in the chat?
>> Student: Octavio says, yes, but where do you recommend putting the images for the README?
>> Jerome Hardaway: I recommend at the bottom just because I wanna lead with the how to get the product running first versus the visual aids, so but the good thing is if they are looking at your READMEs, you are winning, right?

[00:03:00]
There you are in repos and READMEs, you have passed user zero, you're past user one, you are now and In your past user to you, so you are out of your own way the ATS is giving you the thumbs up HR. Is also like saying this is a good candidate.

[00:03:23]
So now you're in the end zone, you're like, okay, the developers I hear, I am on what I guess in sports, it'd be like third base. You go to your almost home, right? You go to third base, that's like six. [LAUGH] It was like, why does this third base have six rounds of third base?

[00:03:40]
But you're still, you're a lot closer to home than the person who is on first or hasn't gotten up to bat yet, so that's good.

